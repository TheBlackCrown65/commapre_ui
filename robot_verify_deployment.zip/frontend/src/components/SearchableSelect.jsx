import React, { useState, useRef, useEffect } from 'react';
import PropTypes from 'prop-types';
import { clsx } from 'clsx';
import { ChevronDown, Search, Check } from 'lucide-react';

export default function SearchableSelect({
    options = [],
    value,
    onChange,
    placeholder = "Select...",
    disabled = false,
    className = ""
}) {
    const [isOpen, setIsOpen] = useState(false);
    const [searchTerm, setSearchTerm] = useState('');
    const wrapperRef = useRef(null);

    useEffect(() => {
        function handleClickOutside(event) {
            if (wrapperRef.current && !wrapperRef.current.contains(event.target)) {
                setIsOpen(false);
                setSearchTerm('');
            }
        }
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    const selectedOption = options.find(opt => opt.value === value);

    const filteredOptions = options.filter(opt =>
        opt.label.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div ref={wrapperRef} className={clsx("relative w-full sm:min-w-[200px]", className)}>
            <button
                type="button"
                onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        if (!disabled) setIsOpen(!isOpen);
                    }
                }}
                className={clsx(
                    "flex items-center justify-between border-2 rounded-lg p-2 transition-all outline-none",
                    disabled ? "border-slate-200 bg-slate-50 text-slate-400 cursor-not-allowed" : "cursor-pointer bg-white focus:border-teal-500 focus:ring-1 focus:ring-teal-500",
                    !disabled && !value ? "border-teal-500 text-teal-600 font-bold shadow-sm" : "",
                    !disabled && value ? "border-teal-500 text-teal-700 font-medium shadow-sm hover:border-teal-600" : ""
                )}
                onClick={() => !disabled && setIsOpen(!isOpen)}
                disabled={disabled}
            >
                <span className="truncate pr-2">{selectedOption ? selectedOption.label : placeholder}</span>
                <ChevronDown size={16} className={clsx("transition-transform", isOpen && "rotate-180")} />
            </button>

            {isOpen && (
                <div className="absolute z-50 w-full mt-1 bg-white border border-slate-200 rounded-lg shadow-xl max-h-60 overflow-y-auto">
                    <div className="sticky top-0 bg-white p-2 border-b border-slate-100">
                        <div className="relative">
                            <Search size={14} className="absolute left-2.5 top-2.5 text-slate-400" />
                            <input
                                type="text"
                                className="w-full pl-8 pr-3 py-1.5 text-sm bg-slate-50 border border-slate-200 rounded-md focus:outline-none focus:border-teal-500 focus:ring-1 focus:ring-teal-500"
                                placeholder="Search..."
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                onClick={(e) => e.stopPropagation()}
                                autoFocus
                            />
                        </div>
                    </div>
                    
                    {filteredOptions.length === 0 ? (
                        <div className="p-3 text-sm text-center text-slate-500">No results found</div>
                    ) : (
                        <div className="p-1">
                            {filteredOptions.map((opt) => {
                                // Highlight matching text
                                const matchIndex = opt.label.toLowerCase().indexOf(searchTerm.toLowerCase());
                                let highlightedLabel = opt.label;
                                
                                if (searchTerm && matchIndex !== -1) {
                                    const beforeMatch = opt.label.slice(0, matchIndex);
                                    const matchText = opt.label.slice(matchIndex, matchIndex + searchTerm.length);
                                    const afterMatch = opt.label.slice(matchIndex + searchTerm.length);
                                    
                                    highlightedLabel = (
                                        <>
                                            {beforeMatch}
                                            <span className="bg-yellow-200 text-teal-900 font-bold px-0.5 rounded-sm">{matchText}</span>
                                            {afterMatch}
                                        </>
                                    );
                                }

                                return (
                                    <button
                                        key={opt.value}
                                        type="button"
                                        className={clsx(
                                            "w-full flex items-center justify-between px-3 py-2 text-sm rounded-md cursor-pointer hover:bg-teal-50 transition-colors focus:outline-none focus:bg-teal-50",
                                            value === opt.value ? "bg-teal-100 text-teal-800 font-medium" : "text-slate-700"
                                        )}
                                        onClick={(e) => {
                                            e.preventDefault();
                                            onChange(opt.value);
                                            setIsOpen(false);
                                            setSearchTerm('');
                                        }}
                                    >
                                        <span className="truncate">{highlightedLabel}</span>
                                        {value === opt.value && <Check size={14} className="text-teal-600" />}
                                    </button>
                                );
                            })}
                        </div>
                    )}
                </div>
            )}
        </div>
    );
}

SearchableSelect.propTypes = {
    options: PropTypes.arrayOf(
        PropTypes.shape({
            label: PropTypes.string.isRequired,
            value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired
        })
    ),
    value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    onChange: PropTypes.func.isRequired,
    placeholder: PropTypes.string,
    disabled: PropTypes.bool,
    className: PropTypes.string
};
